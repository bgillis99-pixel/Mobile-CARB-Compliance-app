
import React, { useState, useEffect, Suspense } from 'react';
import VinChecker from './components/VinChecker';
import ComplianceGuide from './components/ComplianceGuide';
import ClientIntake from './components/ClientIntake';
import LandingView from './components/LandingView';
import { AppView, User, HistoryItem, CrmClient, IntakeSubmission } from './types';
import { initGA, trackPageView, trackEvent } from './services/analytics';
import { auth, getHistoryFromCloud, onAuthStateChanged, saveScanToCloud } from './services/firebase'; 
import { triggerHaptic } from './services/haptics';

const ChatAssistant = React.lazy(() => import('./components/ChatAssistant'));
const LiveAssistant = React.lazy(() => import('./components/LiveAssistant'));
const MediaTools = React.lazy(() => import('./components/MediaTools'));
const ProfileView = React.lazy(() => import('./components/ProfileView'));
const GarageView = React.lazy(() => import('./components/GarageView'));
const AdminView = React.lazy(() => import('./components/AdminView'));
const InvoiceApp = React.lazy(() => import('./components/InvoiceApp'));

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING); 
  const [user, setUser] = useState<User | null>(null);
  const [localHistory, setLocalHistory] = useState<HistoryItem[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [activeInvoiceData, setActiveInvoiceData] = useState<any>(null);

  useEffect(() => {
    // CAPTURE REFERRAL DATA
    const referrer = document.referrer;
    const urlParams = new URLSearchParams(window.location.search);
    const source = urlParams.get('utm_source') || (referrer ? new URL(referrer).hostname : 'Direct / Organic');
    
    const trafficLogs = JSON.parse(localStorage.getItem('carb_traffic_logs') || '[]');
    if (!localStorage.getItem('session_tracked')) {
        trafficLogs.push({ source, timestamp: Date.now(), landing: window.location.pathname });
        localStorage.setItem('carb_traffic_logs', JSON.stringify(trafficLogs.slice(-100)));
        localStorage.setItem('session_tracked', 'true');
    }

    const saved = localStorage.getItem('carb_vin_history');
    if (saved) {
      try { setLocalHistory(JSON.parse(saved)); } catch (e) { console.error(e); }
    }
  }, []);

  useEffect(() => {
    initGA();
    onAuthStateChanged(auth, async (firebaseUser: any) => {
        if (firebaseUser) {
            const cloudHistory = await getHistoryFromCloud(firebaseUser.uid);
            setUser({ email: firebaseUser.email || 'Operator', history: [...cloudHistory as HistoryItem[]] });
            if (currentView === AppView.LANDING) setCurrentView(AppView.HOME);
        } else { 
            setUser({ email: 'Guest Operator', history: localHistory });
        }
    });

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [localHistory]);

  useEffect(() => { trackPageView(currentView); }, [currentView]);

  const handleAddToHistory = (value: string, type: 'VIN' | 'ENTITY' | 'TRUCRS') => {
    const newItem: HistoryItem = { id: Date.now().toString(), value: value.toUpperCase(), type, timestamp: Date.now() };
    const updatedLocal = [newItem, ...localHistory].slice(0, 50);
    setLocalHistory(updatedLocal);
    localStorage.setItem('carb_vin_history', JSON.stringify(updatedLocal));
    if (auth?.currentUser) saveScanToCloud(auth.currentUser.uid, newItem);
  };

  const handleShare = async () => {
    triggerHaptic('medium');
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Mobile CARB Compliance',
          text: 'Check your CARB compliance status instantly!',
          url: window.location.origin,
        });
      } catch (err) { console.log(err); }
    } else {
      alert("Link copied: " + window.location.origin);
    }
  };

  const startInvoiceForClient = (data: any) => {
    setActiveInvoiceData(data);
    setCurrentView(AppView.INVOICE);
    triggerHaptic('medium');
  };

  const navigateToChat = (prompt?: string) => {
    if (prompt) {
      localStorage.setItem('initial_chat_prompt', prompt);
    }
    setCurrentView(AppView.ASSISTANT);
  };

  if (currentView === AppView.LANDING) {
    return (
      <LandingView 
        onLaunch={() => setCurrentView(AppView.HOME)} 
        onNavigateTools={() => setCurrentView(AppView.ANALYZE)} 
        onNavigateIntake={() => setCurrentView(AppView.INTAKE)}
        onNavigateChat={navigateToChat}
        onNavigateAdmin={() => setCurrentView(AppView.ADMIN)}
      />
    );
  }

  const MetallicStyle = "bg-gradient-to-b from-[#f3f4f6] via-[#d1d5db] to-[#9ca3af] shadow-md border border-white/20 relative overflow-hidden transition-all";
  const isSpecialView = currentView === AppView.INTAKE || currentView === AppView.INVOICE;
  const isAdminView = currentView === AppView.ADMIN;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 overflow-x-hidden selection:bg-carb-accent">
        <header className="pt-safe px-4 py-4 fixed top-0 left-0 right-0 glass-dark bg-carb-navy z-[100] border-b border-white/5 shadow-xl transition-all duration-300">
          <div className="flex flex-col gap-4 w-full max-w-md mx-auto">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <button onClick={() => setCurrentView(AppView.HOME)} className="h-9 px-4 rounded-xl metallic-silver transition-all active:scale-95 border-white/40 shadow-md flex items-center justify-center">
                  <span className="text-[9px] font-black uppercase tracking-widest text-[#020617] italic leading-none">{isSpecialView ? 'BACK' : 'HOME'}</span>
                </button>
                <div 
                  className={`w-2 h-2 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)] ${isOnline ? 'bg-carb-green animate-pulse' : 'bg-rose-500'}`}
                  title={isOnline ? 'System Online' : 'System Offline'}
                />
              </div>

              {!isAdminView && (
                <div className="flex gap-2">
                   <headerUtilityBtn onClick={() => alert('Add to Home Screen')} icon={<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>} />
                   <headerUtilityBtn onClick={handleShare} icon={<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>} />
                   <headerUtilityBtn onClick={() => navigateToChat()} icon={<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} />
                </div>
              )}
            </div>
            
            {!isSpecialView && (
              <nav className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                  {[
                    { id: AppView.HOME, label: 'HUB' },
                    { id: AppView.ADMIN, label: 'OPS' },
                    { id: AppView.LIVE_ASSISTANT, label: 'LIVE' },
                    { id: AppView.GARAGE, label: 'FLEET' },
                    { id: AppView.PROFILE, label: 'LOG' },
                  ].map(item => (
                    <button 
                      key={item.id} 
                      onClick={() => { triggerHaptic('light'); setCurrentView(item.id); }} 
                      className={`h-9 px-3 flex-shrink-0 flex items-center justify-center rounded-xl transition-all ${currentView === item.id ? 'bg-carb-accent text-white scale-105 shadow-lg' : 'opacity-80'} ${MetallicStyle}`}
                    >
                      <span className={`text-[9px] font-black tracking-widest uppercase relative z-10 ${currentView === item.id ? 'text-white' : 'text-white text-glow'}`}>{item.label}</span>
                    </button>
                  ))}
              </nav>
            )}
          </div>
        </header>

        <main className={`flex-1 overflow-y-auto ${isSpecialView ? 'pt-24' : 'pt-32'} pb-40`}>
            <div className="px-6">
                <Suspense fallback={<div className="flex justify-center py-20 animate-pulse text-gray-400 uppercase font-black text-[10px] tracking-widest">Syncing Hub...</div>}>
                    {currentView === AppView.HOME && (
                        <div className="animate-in fade-in duration-700 space-y-12">
                          <VinChecker onAddToHistory={handleAddToHistory} onNavigateChat={() => navigateToChat()} onShareApp={() => {}} onNavigateTools={() => setCurrentView(AppView.ANALYZE)} />
                          <div className="h-px w-full bg-slate-200"></div>
                          <ComplianceGuide onNavigateTools={() => setCurrentView(AppView.ANALYZE)} />
                        </div>
                    )}
                    {currentView === AppView.INTAKE && <ClientIntake onComplete={() => setCurrentView(AppView.HOME)} />}
                    {currentView === AppView.INVOICE && <InvoiceApp initialData={activeInvoiceData} onComplete={() => { setActiveInvoiceData(null); setCurrentView(AppView.HOME); }} />}
                    {currentView === AppView.ASSISTANT && <ChatAssistant />}
                    {currentView === AppView.LIVE_ASSISTANT && <LiveAssistant onClose={() => setCurrentView(AppView.HOME)} />}
                    {currentView === AppView.GARAGE && <GarageView user={user} onNavigateLogin={() => setCurrentView(AppView.PROFILE)} />}
                    {currentView === AppView.ANALYZE && <MediaTools />}
                    {currentView === AppView.PROFILE && <ProfileView user={user} onLogout={() => setUser(null)} onAdminAccess={() => setCurrentView(AppView.ADMIN)} />}
                    {currentView === AppView.ADMIN && <AdminView onNavigateInvoice={(data) => startInvoiceForClient(data)} />}
                </Suspense>
            </div>
        </main>

        {/* Global Bottom Actions (Download/Share/Help) */}
        {!isAdminView && (
          <div className="fixed bottom-0 left-0 right-0 p-4 pb-safe bg-white/95 backdrop-blur-md border-t border-slate-200 z-[100] flex justify-between items-center max-w-md mx-auto shadow-[0_-10px_30px_rgba(0,0,0,0.1)]">
             <div className="flex gap-4">
                <BottomActionBtn onClick={() => alert('Install App')} label="Install" icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>} />
                <BottomActionBtn onClick={handleShare} label="Share" icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>} />
             </div>

             <button onClick={() => { triggerHaptic('medium'); setCurrentView(AppView.LANDING); }} className="px-6 py-4 metallic-silver rounded-2xl text-[10px] font-black uppercase tracking-widest italic shadow-lg border border-white/20 active:scale-95 transition-all">
               HUB EXIT
             </button>

             <BottomActionBtn onClick={() => navigateToChat()} label="Help" accent icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} />
          </div>
        )}
    </div>
  );
};

const headerUtilityBtn = ({ onClick, icon }: { onClick: () => void, icon: React.ReactNode }) => (
  <button onClick={onClick} className="p-2.5 bg-white/5 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-all active:scale-90 border border-white/5">
    {icon}
  </button>
);

const BottomActionBtn = ({ onClick, icon, label, accent = false }: { onClick: () => void, icon: React.ReactNode, label: string, accent?: boolean }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-1 active:scale-95 transition-all">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all shadow-md ${accent ? 'bg-carb-accent text-white' : 'bg-slate-900 text-white'}`}>
          {icon}
      </div>
      <span className={`text-[8px] font-black uppercase tracking-widest ${accent ? 'text-carb-accent' : 'text-slate-500'}`}>{label}</span>
  </button>
);

export default App;
