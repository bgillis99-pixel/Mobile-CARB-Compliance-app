
import React, { useState, useEffect, useMemo } from 'react';
import { getClientsFromCRM, subscribeToInboundIntakes, saveClientToCRM } from '../services/firebase';
import { unslopContacts, sendMessage } from '../services/geminiService';
import { CrmClient, IntakeSubmission } from '../types';
import { triggerHaptic } from '../services/haptics';

interface Props {
  onNavigateInvoice: (data?: any) => void;
}

type ViewMode = 'DASHBOARD' | 'INTAKES' | 'CRM' | 'RECOVERY' | 'GIT OPS' | 'CLOUD SYNC' | 'CLAUDE MAX';

const AdminView: React.FC<Props> = ({ onNavigateInvoice }) => {
  const [passInput, setPassInput] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [adminCode] = useState('1225');
  const [viewMode, setViewMode] = useState<ViewMode>('DASHBOARD');
  const [intakes, setIntakes] = useState<IntakeSubmission[]>([]);
  const [crmClients, setCrmClients] = useState<CrmClient[]>([]);
  
  // Claude Logic State
  const [claudeQuery, setClaudeQuery] = useState('');
  const [claudeResponse, setClaudeResponse] = useState('');
  const [isReasoning, setIsReasoning] = useState(false);

  useEffect(() => {
    if (isAuthorized) {
        const unsub = subscribeToInboundIntakes((data) => setIntakes(data));
        getClientsFromCRM().then(data => setCrmClients(data));
        return () => unsub();
    }
  }, [isAuthorized]);

  const handleLogin = () => {
    triggerHaptic('medium');
    if (passInput === adminCode) { 
      setIsAuthorized(true); 
      triggerHaptic('success'); 
    } else { 
      triggerHaptic('error'); 
      alert("Access Denied. Authorization Protocol Required."); 
    }
  };

  const handleClaudeReasoning = async () => {
    if (!claudeQuery.trim()) return;
    setIsReasoning(true);
    triggerHaptic('heavy');
    try {
      const result = await sendMessage(`[DEEP REASONING MODE] Analyze this complex fleet/regulatory query: ${claudeQuery}`, [], undefined);
      setClaudeResponse(result.text);
      triggerHaptic('success');
    } catch (e) {
      setClaudeResponse("REASONING ENGINE FAILURE. Check logic protocols.");
    } finally {
      setIsReasoning(false);
    }
  };

  const StatBox = ({ label, value }: { label: string, value: string }) => (
    <div className="bg-[#9ca3af] p-8 rounded-[2.5rem] shadow-sm flex flex-col justify-start items-start aspect-[16/9] sm:aspect-auto">
       <p className="text-[10px] font-black text-slate-700 uppercase tracking-widest mb-2 opacity-60">{label}</p>
       <p className="text-4xl font-black italic text-white tracking-tighter">{value}</p>
    </div>
  );

  if (!isAuthorized) {
    return (
      <div className="flex flex-col items-center justify-center pt-10 animate-in fade-in duration-500">
        <div className="w-full max-w-[340px] bg-[#0f172a] p-12 rounded-[4rem] border border-white/10 text-center space-y-10 shadow-2xl relative">
            {/* Glossy overlay effect for the card */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent rounded-[4rem] pointer-events-none"></div>
            
            <div className="space-y-3 relative z-10">
              <h2 className="text-4xl font-black italic uppercase text-white tracking-tighter leading-none">COMMAND</h2>
              <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] italic">Authorization Protocol Required</p>
            </div>
            
            <div className="bg-[#020617] rounded-[2.5rem] p-8 shadow-inner border border-white/5 relative z-10">
                <input 
                  type="password" 
                  value={passInput} 
                  onChange={e => setPassInput(e.target.value)} 
                  placeholder="••••" 
                  className="w-full bg-transparent text-center text-4xl font-black tracking-[0.5em] outline-none text-white placeholder:text-slate-800" 
                  onKeyDown={e => e.key === 'Enter' && handleLogin()}
                  autoFocus
                />
            </div>

            <button 
              onClick={handleLogin} 
              className="w-full py-6 bg-blue-600 hover:bg-blue-500 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] text-[11px] active-haptic shadow-[0_15px_35px_rgba(37,99,235,0.4)] transition-all relative z-10"
            >
              Access Console
            </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-32 max-w-4xl mx-auto">
       <div className="flex gap-2 overflow-x-auto no-scrollbar items-center bg-[#0f172a] p-2.5 rounded-[2.5rem] border border-white/5">
          {['DASHBOARD', 'INTAKES', 'CRM', 'RECOVERY', 'GIT OPS', 'CLOUD SYNC', 'CLAUDE MAX'].map(m => (
            <button 
              key={m} 
              onClick={() => { 
                triggerHaptic('light'); 
                setViewMode(m as any); 
              }}
              className={`px-6 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest italic transition-all whitespace-nowrap ${viewMode === m ? 'bg-carb-accent text-white shadow-lg' : 'bg-[#1e293b] text-slate-400 hover:bg-[#334155]'}`}
            >
              {m}
            </button>
          ))}
       </div>

       {viewMode === 'CLAUDE MAX' && (
         <div className="animate-in fade-in duration-500 space-y-8">
            <div className="bg-[#cbd5e1] p-10 rounded-[3.5rem] border border-slate-200 space-y-8 shadow-sm relative overflow-hidden">
               <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/brushed-alum.png')] opacity-10 pointer-events-none"></div>
               <div className="relative z-10 space-y-6">
                  <div className="space-y-2">
                    <h3 className="text-4xl font-black italic text-slate-950 uppercase tracking-tighter">CLAUDE LOGIC CORE</h3>
                    <p className="text-[10px] font-black text-carb-accent uppercase tracking-widest italic">Deep Reasoning Backend Terminal (MAX Tier)</p>
                  </div>
                  <div className="space-y-4">
                    <textarea 
                      value={claudeQuery}
                      onChange={(e) => setClaudeQuery(e.target.value)}
                      placeholder="Input complex fleet audit data or regulatory cross-reference requests here..."
                      className="w-full h-40 bg-white/40 border border-slate-300 rounded-[2rem] p-8 text-sm font-bold text-slate-900 outline-none focus:border-carb-accent/40 resize-none italic"
                    />
                    <button 
                      onClick={handleClaudeReasoning}
                      disabled={isReasoning || !claudeQuery.trim()}
                      className={`w-full py-8 text-white rounded-[2.5rem] font-black uppercase tracking-widest text-[11px] italic shadow-2xl active-haptic disabled:opacity-30 transition-all ${isReasoning ? 'bg-slate-900' : 'bg-carb-accent'}`}
                    >
                      {isReasoning ? 'REASONING THROUGH DATA...' : 'ACTIVATE CLAUDE MAX LOGIC'}
                    </button>
                  </div>
               </div>
            </div>
            {claudeResponse && (
               <div className="bg-[#0f172a] p-10 rounded-[3.5rem] border border-carb-accent/30 space-y-6 animate-in slide-in-from-bottom-6 duration-700">
                  <div className="flex justify-between items-center">
                     <h4 className="text-[10px] font-black text-carb-accent uppercase tracking-widest italic">Logic Output Terminal</h4>
                     <button onClick={() => setClaudeResponse('')} className="text-slate-600 text-[10px] font-black hover:text-white">CLEAR</button>
                  </div>
                  <div className="bg-black/40 p-8 rounded-3xl border border-white/5">
                     <p className="text-sm font-bold text-slate-100 leading-relaxed whitespace-pre-wrap font-mono">{claudeResponse}</p>
                  </div>
                  <p className="text-[8px] font-bold text-slate-700 uppercase tracking-widest text-center italic">Reasoning derived from 2026 CARB Regulatory Mapping (Gemini Pro Core)</p>
               </div>
            )}
         </div>
       )}

       {viewMode === 'DASHBOARD' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <StatBox label="REVENUE MTD" value="$14,250" />
                <StatBox label="ACTIVE INVOICES" value="09" />
                <StatBox label="COMPLIANCE %" value="98.4%" />
                <StatBox label="PENDING INTAKES" value={intakes.length.toString()} />
             </div>
             <div className="bg-[#cbd5e1] p-10 rounded-[3.5rem] space-y-8 shadow-sm">
                <div className="flex justify-between items-center">
                   <h3 className="text-[10px] font-black text-slate-700 uppercase tracking-widest italic opacity-70">LIVE OPERATIONS FEED</h3>
                   <span className="text-[8px] font-black text-carb-accent bg-carb-accent/10 px-4 py-1.5 rounded-full uppercase italic border border-carb-accent/20">REAL-TIME SYNC</span>
                </div>
                {intakes.length === 0 ? (
                  <div className="py-20 text-center">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest italic">Monitoring compliance pipelines...</p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-300">
                    {intakes.slice(0, 5).map(i => (
                      <div key={i.id} className="py-6 flex justify-between items-center group">
                          <div className="space-y-1">
                            <p className="text-lg font-black text-slate-900 italic group-hover:text-carb-accent transition-colors">{i.clientName}</p>
                            <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">
                              VIN: {(i.extractedData as any)?.vin || '---'} | {new Date(i.timestamp).toLocaleDateString()}
                            </p>
                          </div>
                          <button 
                            onClick={() => onNavigateInvoice({ clientName: i.clientName, ...i.extractedData })} 
                            className="w-12 h-12 bg-white/50 hover:bg-white flex items-center justify-center rounded-2xl shadow-sm transition-all"
                          >📄</button>
                      </div>
                    ))}
                  </div>
                )}
             </div>
          </div>
       )}
    </div>
  );
};

export default AdminView;
