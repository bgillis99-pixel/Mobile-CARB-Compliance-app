
import React, { useState, useEffect } from 'react';
import { triggerHaptic } from '../services/haptics';

interface Props {
  onLaunch: () => void;
  onNavigateTools: () => void;
  onNavigateIntake: () => void;
  onNavigateChat: (prompt?: string) => void;
  onNavigateAdmin: () => void;
}

const DOWNLOAD_ICON = (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
);
const SHARE_ICON = (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
);
const CONTACT_ICON = (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const PHONE_ICON = (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
);
const MSG_ICON = (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" /></svg>
);

const COMPLIANCE_TICKER = [
  "🚛 PRO-TIP: THE STATE WON'T TELL YOU, BUT MISSING YOUR PSIP TEST BY 1 DAY TRIGGERS A LOCK.",
  "⚠️ JAN 1 DEADLINE: Annual reporting fee due for all registered entities.",
  "📍 NEW: Grounding tools added for finding local credentialed OBD testers.",
  "📋 SMART SYNC: Use Intake to archive your engine family tags proactively.",
  "✨ AI ADVICE: Ask our assistant about hidden TRUCRS portal fees."
];

const LandingView: React.FC<Props> = ({ onLaunch, onNavigateTools, onNavigateIntake, onNavigateChat, onNavigateAdmin }) => {
  const [tickerIndex, setTickerIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % COMPLIANCE_TICKER.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const MetallicStyle = "bg-gradient-to-b from-slate-100 via-slate-300 to-slate-400 shadow-[0_10px_25px_rgba(0,0,0,0.2),inset_0_1px_1px_rgba(255,255,255,0.8)] border border-slate-200 relative overflow-hidden transition-all";
  const BrushedTexture = <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/brushed-alum.png')] opacity-10 pointer-events-none"></div>;

  const handleShare = async () => {
    triggerHaptic('medium');
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Mobile CARB Compliance',
          text: 'Check your CARB compliance status instantly!',
          url: window.location.origin,
        });
      } catch (err) { console.log(err); }
    } else {
      alert("Link copied: " + window.location.origin);
    }
  };

  const MainButton = ({ label, onClick, accent = false }: { label: string, onClick: () => void, accent?: boolean }) => (
    <div className={`p-1 rounded-[1.5rem] bg-slate-800/60 border border-white/10 ${accent ? 'ring-2 ring-carb-accent/30' : ''}`}>
        <button 
            onClick={onClick}
            className={`w-full py-6 text-slate-900 font-black rounded-[1.2rem] uppercase tracking-[0.2em] italic text-base hover:scale-[1.01] active:scale-[0.98] transition-all ${MetallicStyle}`}
        >
            {BrushedTexture}
            <span className="relative z-10">{label}</span>
        </button>
    </div>
  );

  return (
    <main className="min-h-screen bg-carb-navy flex flex-col items-center justify-start px-4 py-4 text-center animate-in fade-in duration-1000 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-blue-500/10 rounded-full blur-[120px] animate-pulse-slow"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]"></div>
      </div>

      <div className="relative z-10 max-w-lg w-full flex flex-col items-center gap-2">
        
        {/* TICKER AT TOP */}
        <button 
          onClick={() => {
            triggerHaptic('light');
            onNavigateChat(COMPLIANCE_TICKER[tickerIndex]);
          }}
          className="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 min-h-[44px] flex items-center justify-center overflow-hidden transition-colors hover:bg-slate-800/80 active-haptic mb-2"
        >
           <p className="text-[10px] font-black text-white uppercase tracking-widest italic animate-in slide-in-from-right-10 duration-500" key={tickerIndex}>
              {COMPLIANCE_TICKER[tickerIndex]}
           </p>
        </button>

        {/* LOGO (NO CENTER) */}
        <div className="flex flex-col items-center justify-center transform scale-90 sm:scale-100 py-2">
            <h1 className="text-5xl sm:text-6xl font-black tracking-[0.15em] text-slate-100 drop-shadow-lg leading-none" style={{ fontFamily: 'Arial, sans-serif' }}>MOBILE</h1>
            <h1 className="text-7xl sm:text-8xl font-black tracking-[0.15em] text-carb-green drop-shadow-lg leading-none -mt-2" style={{ fontFamily: 'Arial, sans-serif' }}>CARB</h1>
            <div className="flex flex-col items-center gap-1 mt-1">
              <span className="text-2xl sm:text-3xl font-black text-slate-400 tracking-[0.4em] italic uppercase">COMPLIANCE</span>
            </div>
        </div>

        {/* TOP UTILITY BUTTONS */}
        <div className="flex justify-center gap-6 w-full py-4">
            <UtilityBtn icon={DOWNLOAD_ICON} label="Install" onClick={() => alert('Add to Home Screen')} />
            <UtilityBtn icon={SHARE_ICON} label="Share" onClick={handleShare} />
            <UtilityBtn icon={CONTACT_ICON} label="Help" onClick={() => onNavigateChat()} />
        </div>

        {/* LARGE NAVIGATION BUTTONS */}
        <div className="w-full bg-slate-800/20 border border-white/5 rounded-[2.5rem] p-4 backdrop-blur-3xl shadow-2xl space-y-4">
            <MainButton label="Instant VIN Lookup" onClick={onLaunch} accent />
            <MainButton label="Document Intake (Smart Sync)" onClick={onNavigateIntake} />
            <MainButton label="Find Credentialed Tester" onClick={onNavigateTools} />
            <MainButton label="AI Regulatory Assistant" onClick={() => onNavigateChat()} />
        </div>

        {/* BOTTOM ACTION BAR */}
        <div className="mt-6 space-y-4 w-full">
            <div className="bg-slate-800/40 border border-white/5 p-4 rounded-[2rem] backdrop-blur-3xl shadow-xl flex justify-around items-center">
                <ActionBtn icon={PHONE_ICON} label="CALL" onClick={() => window.open('tel:9168904427')} />
                <ActionBtn icon={MSG_ICON} label="SMS" onClick={() => window.location.href="sms:19168904427&body=Help with CARB Compliance"} />
                <ActionBtn icon={CONTACT_ICON} label="RESOURCES" onClick={() => onNavigateChat()} />
                <ActionBtn icon={<span className="text-xl">⚙️</span>} label="ADMIN" onClick={onNavigateAdmin} />
            </div>

            <div className="px-8 text-center space-y-1 pb-4">
              <p className="text-[7px] font-black text-slate-500 uppercase tracking-[0.3em] italic">
                A private proactive initiative to fill the state's education gap.
              </p>
              <p className="text-[7px] font-bold text-slate-700 uppercase tracking-widest">
                © 2026 SILVERBACK GROUP LLC • EST. CALIFORNIA
              </p>
            </div>
        </div>
      </div>
    </main>
  );
};

const UtilityBtn = ({ icon, label, onClick }: { icon: React.ReactNode, label: string, onClick: () => void }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-2 active-haptic group">
      <div className="w-16 h-16 rounded-2xl bg-slate-800/50 border border-white/10 flex items-center justify-center text-slate-300 group-hover:bg-carb-accent group-hover:text-slate-900 group-hover:scale-105 transition-all shadow-lg">
          {icon}
      </div>
      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{label}</span>
  </button>
);

const ActionBtn = ({ icon, label, onClick }: { icon: React.ReactNode, label: string, onClick: () => void }) => {
  const MetallicStyle = "bg-gradient-to-b from-slate-100 via-slate-200 to-slate-300 shadow-sm border border-slate-200 relative overflow-hidden";
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5 active-haptic group">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-slate-700 ${MetallicStyle}`}>
         <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/brushed-alum.png')] opacity-10"></div>
         <div className="relative z-10 group-hover:scale-110 transition-transform">{icon}</div>
      </div>
      <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{label}</span>
    </button>
  );
};

export default LandingView;
