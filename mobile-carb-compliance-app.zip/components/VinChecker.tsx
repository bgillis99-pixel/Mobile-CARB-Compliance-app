
import React, { useState, useRef, useEffect } from 'react';
import { extractVinAndPlateFromImage, validateVINCheckDigit, repairVin } from '../services/geminiService';
import { decodeVinNHTSA, NHTSAVehicle } from '../services/nhtsa';
import { triggerHaptic } from '../services/haptics';
import { lookupCompliance } from '../lib/compliance';

const CAMERA_ICON = (
  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
);

const VinChecker: React.FC<{ onAddToHistory: (v: string, t: 'VIN') => void, onNavigateChat: () => void, onNavigateTools: () => void, onShareApp: () => void }> = ({ onAddToHistory, onNavigateChat }) => {
  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorCorrection, setErrorCorrection] = useState<string | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState<NHTSAVehicle | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showResultScreen, setShowResultScreen] = useState<'compliant' | 'non-compliant' | 'unknown' | null>(null);
  const [unknownMessage, setUnknownMessage] = useState('');

  const MetallicStyle = "bg-gradient-to-b from-slate-100 via-slate-300 to-slate-400 shadow-md border border-slate-200 relative overflow-hidden transition-all";
  const BrushedTexture = <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/brushed-alum.png')] opacity-15 pointer-events-none"></div>;

  useEffect(() => {
    if (!inputVal) { setErrorCorrection(null); return; }
    if (inputVal.length === 17) {
        handleVerification(inputVal);
    }
  }, [inputVal]);

  const handleVerification = async (vin: string) => {
    if (!validateVINCheckDigit(vin)) {
        setErrorCorrection('Check-Digit Mismatch.');
        return;
    }
    setLoading(true);
    try {
        const data = await decodeVinNHTSA(vin);
        if (data && data.valid) setVehicleDetails(data);
    } catch (err) {}
    finally { setLoading(false); }
  };

  const triggerComplianceCheck = async () => {
    setShowConfirmModal(false);
    setLoading(true);
    triggerHaptic('medium');
    try {
        const result = await lookupCompliance(inputVal);
        if (result.status === 'COMPLIANT') {
            setShowResultScreen('compliant');
            onAddToHistory(inputVal, 'VIN');
            triggerHaptic('success');
        } else if (result.status === 'NOT_COMPLIANT') {
            setShowResultScreen('non-compliant');
            onAddToHistory(inputVal, 'VIN');
            triggerHaptic('error');
        } else {
            setShowResultScreen('unknown');
            setUnknownMessage(result.message || 'sorry my carbs are crossed. try later');
            triggerHaptic('medium');
        }
    } catch (e) {
        setShowResultScreen('unknown');
        setUnknownMessage('sorry my carbs are crossed. try later');
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-6 pb-8 animate-in fade-in duration-700">
      <section className="bg-slate-800/40 border border-white/5 rounded-[3rem] p-8 shadow-2xl space-y-6 relative overflow-hidden backdrop-blur-2xl">
          <h2 className="text-slate-100 font-black text-2xl uppercase tracking-tighter text-center italic relative z-10">VIN LOOKUP <span className="text-carb-accent">›</span></h2>
          <div className="space-y-4 relative z-10">
              <div className="bg-slate-900/60 rounded-3xl border border-white/10 p-1 focus-within:border-carb-accent/50 transition-all shadow-inner">
                <input 
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value.toUpperCase())}
                  placeholder="ENTER VIN"
                  maxLength={17}
                  className="w-full bg-transparent py-5 px-6 text-center text-xl font-black text-white outline-none vin-monospace placeholder:text-slate-700 tracking-widest uppercase"
                />
              </div>
              {errorCorrection && <p className="text-center text-[10px] font-black uppercase text-rose-400">{errorCorrection}</p>}
              {vehicleDetails && <p className="text-center text-[10px] font-bold text-carb-green uppercase italic">{vehicleDetails.year} {vehicleDetails.make} {vehicleDetails.model}</p>}
          </div>
          <button 
            disabled={inputVal.length < 11 || loading}
            onClick={() => { triggerHaptic('light'); setShowConfirmModal(true); }}
            className={`w-full py-5 text-slate-900 font-black rounded-3xl uppercase tracking-[0.3em] text-[10px] active-haptic disabled:opacity-30 italic ${MetallicStyle}`}
          >
            {BrushedTexture}
            <span className="relative z-10">{loading ? 'SCANNING HUB...' : 'SHIELD VERIFICATION'}</span>
          </button>
      </section>

      {showResultScreen && (
        <div className={`fixed inset-0 z-[2000] flex flex-col items-center justify-center p-8 animate-in fade-in duration-500 ${showResultScreen === 'compliant' ? 'bg-emerald-950/95' : showResultScreen === 'non-compliant' ? 'bg-rose-950/95' : 'bg-slate-900/95'} backdrop-blur-2xl`}>
             <div className="text-center space-y-8 w-full max-w-sm">
                <div className={`w-32 h-32 rounded-full mx-auto flex items-center justify-center border-[6px] ${showResultScreen === 'compliant' ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' : showResultScreen === 'non-compliant' ? 'bg-rose-500/10 border-rose-500 text-rose-500' : 'bg-slate-500/10 border-slate-500 text-slate-500'}`}>
                    <span className="text-6xl">{showResultScreen === 'compliant' ? '✓' : showResultScreen === 'non-compliant' ? '!' : '?'}</span>
                </div>
                <div className="space-y-4">
                    <h2 className="text-5xl font-black italic uppercase tracking-tighter text-white">
                      {showResultScreen === 'compliant' ? 'COMPLIANT' : showResultScreen === 'non-compliant' ? 'NOT READY' : 'PORTAL ERROR'}
                    </h2>
                    <div className="p-6 bg-white/5 border border-white/10 rounded-[2.5rem] space-y-3">
                       <p className="text-[10px] font-black text-carb-accent uppercase tracking-widest italic text-center">
                         {showResultScreen === 'unknown' ? 'SHIELD RESPONSE' : 'System Report'}
                       </p>
                       <p className="text-sm text-slate-300 font-medium leading-relaxed italic text-center">
                          {showResultScreen === 'compliant' 
                            ? "Vehicle verified as compliant for current reporting window. No immediate action required."
                            : showResultScreen === 'non-compliant'
                            ? "Vehicle detected as Non-Compliant. Testing record required by next reporting window."
                            : unknownMessage}
                       </p>
                    </div>
                </div>
                <button onClick={() => setShowResultScreen(null)} className="text-slate-400 text-[10px] font-black uppercase tracking-[0.5em] pt-4 active:scale-95 transition-all">CLOSE SHIELD</button>
             </div>
        </div>
      )}

      {showConfirmModal && (
        <div className="fixed inset-0 z-[1500] bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-white/10 rounded-[3rem] w-full max-w-sm overflow-hidden shadow-2xl animate-in zoom-in duration-300">
            <div className={`p-8 text-center ${MetallicStyle} rounded-none border-none`}>
              {BrushedTexture}
              <h2 className="text-xl font-black italic uppercase text-slate-900 tracking-tighter relative z-10">Confirm VIN</h2>
            </div>
            <div className="p-8 space-y-6">
              <input value={inputVal} readOnly className="w-full bg-slate-950/40 rounded-2xl border border-white/5 py-4 px-4 text-center text-lg font-black text-white vin-monospace tracking-widest outline-none" />
              <div className="grid grid-cols-2 gap-4">
                  <button onClick={() => setShowConfirmModal(false)} className="py-4 bg-white/5 text-slate-400 border border-white/5 rounded-2xl font-black text-[9px] uppercase italic tracking-widest">EDIT</button>
                  <button onClick={triggerComplianceCheck} className={`py-4 text-slate-900 rounded-2xl font-black text-[9px] uppercase italic tracking-widest ${MetallicStyle}`}>
                    {BrushedTexture}
                    <span className="relative z-10">CONFIRM</span>
                  </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VinChecker;
